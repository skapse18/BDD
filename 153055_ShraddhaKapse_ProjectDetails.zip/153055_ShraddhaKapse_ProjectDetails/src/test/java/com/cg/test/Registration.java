package com.cg.test;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class Registration
{
	@FindBy(id="firstname")
	 WebElement Firstname;
	
	@FindBy(id="lastname")
	 WebElement Lastname;
	
	@FindBy(id="email")
	 WebElement Email;

	
	@FindBy(id="text1")
	 WebElement text1;
	
	
	
	@FindBy(id="address")
	 WebElement address;
	
	@FindBy(id="city")
	 WebElement city;
	
	@FindBy(id="text2")
	 WebElement text2;
	
	@FindBy(id="drop")
	 WebElement drop;
	
	@FindBy(id="submit")
	WebElement submit;
	
	@FindBy(id="projectname")
	WebElement projectname;
	
	@FindBy(id="clientname")
	 WebElement clientname;
	
	@FindBy(id="dropdown")
	 WebElement dropdown;
	
	@FindBy(id="register")
	 WebElement register;
}
