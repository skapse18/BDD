package com.cg.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ProjectSteps
{
	WebDriver driver;
	Registration page1,page2;
	
	@Before
	public void setup()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\Users\\shkapse\\Downloads\\BDDFolder\\selenium client\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@Given("^I am on Registration Page$")
	public void gotoPage()
	{
		driver.get("file:D:\\Users\\shkapse\\Downloads\\BDDFolder\\BDD Workspace\\ProjectDetails\\src\\main\\webapp\\registrationPage.html");
		page1=PageFactory.initElements(driver, Registration.class);
	}
	
	@And("^I enter my firstname as (.*)$")
	public void fName(String fName)
	{
		page1.Firstname.sendKeys(fName);
		//driver.findElement(By.id("firstname")).sendKeys(fName);
	}
	
	@And("^I enter my lastname as (.*)$")
	public void lName(String lName)
	{
		page1.Lastname.sendKeys(lName);
		//driver.findElement(By.id("lastname")).sendKeys(lName);
	}
	
	@And("^I enter my email id as (.*)$")
	public void getEmail(String email)
	{
		page1.Email.sendKeys(email);
		//driver.findElement(By.id("email")).sendKeys(email);
	}
	
	@And("^I enter mobile number as (.*)$")
	public void getMobile(String mobile)
	{
		page1.text1.sendKeys(mobile);
		//driver.findElement(By.id("text1")).sendKeys(mobile);
	}
	
	@And("^I enter address as (.*)$")
	public void getAddress(String address)
	{
		page1.address.sendKeys(address);
		//driver.findElement(By.id("address")).sendKeys(address);
	}

	@And("^I enter city as (.*)$")
	public void getCity(String city)
	{
		page1.text2.sendKeys(city);
		//driver.findElement(By.id("text2")).sendKeys(city);
	}
	
	@And("^I enter state$")
	public void getState()
	{
		WebElement selectState=driver.findElement(By.id("drop"));
		Select select = new Select(selectState);
		select.selectByIndex(2);
	}
	
	@When("^I click on Submit$")
	public void clickSubmit() throws InterruptedException
	{
		Thread.sleep(1000);
		page1.submit.click();
		//driver.findElement(By.id("submit")).click();
	}
	@Then("^I get navigated to another page$")
	public void DisplayMessage1() 
	{
		System.out.println("Navigated to another page");
	}
	
	
	@Given("^I am on Project details page$")
	public void gotoRegister()
	{
		driver.get("D:\\Users\\shkapse\\Downloads\\BDDFolder\\BDD Workspace\\ProjectDetails\\src\\main\\webapp\\nextPage.html");
		page2=PageFactory.initElements(driver, Registration.class);
	}
	
	@And("^I enter Project name as (.*)$")
	public void enterProjectName(String pName)
	{
		page2.projectname.sendKeys(pName);
	//	driver.findElement(By.id("projectname")).sendKeys(pName);
	}
	
	@And("^I enter Client name as (.*)$")
	public void enterClientName(String cName)
	{
		page2.clientname.sendKeys(cName);
		//driver.findElement(By.id("clientname")).sendKeys(cName);
	}
	
	@And("^I enter team size$")
	public void getSize()
	{
		WebElement selectSize=driver.findElement(By.id("dropdown"));
		Select select = new Select(selectSize);
		select.selectByIndex(3);
	}
	
	@When("^I click on Register$")
	public void clickRegister() throws InterruptedException
	{
		Thread.sleep(1000);
		page2.register.click();
		//driver.findElement(By.id("register")).click();
	}
	
	@Then("^I have registered myself successfully$")
	public void DisplayMessage2() 
	{
		System.out.println("You have registered yourself successfully");
	}
	
	

}
